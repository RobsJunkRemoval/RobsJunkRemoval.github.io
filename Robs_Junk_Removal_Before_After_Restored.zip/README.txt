ROB'S JUNK REMOVAL — LATEST WEBSITE
Business phone: 208-420-7272
Business email: RobsJunkRemoval69@gmail.com

Includes:
- Original navy, orange and white design and emojis
- Services, service area, pricing and access policies
- Cash, Cash App, PayPal, Venmo, Chime, Zelle payment options (no public payment handles)
- Customer-requested pickup date/time; Rob must confirm by text
- Text estimate form with instructions for customer to attach junk photos IN Messages
- Phone and email contact links, gallery/review placeholders

NOTE: Browser security prevents automatically adding a photo from a website to an SMS message.
Customers must attach pictures themselves in Messages. SMS deep links may vary by device.
This website does not automatically accept/decline bookings, collect payments or send form emails.

PUBLISH UPDATE:
1. Unzip this package.
2. Open https://github.com/RobsJunkRemoval/RobsJunkRemoval.github.io
3. Upload index.html to repository root, replacing the existing index.html.
4. Commit changes; GitHub Pages should update shortly.
5. Test on your phone and verify SMS draft and date/time are included.

No paid hosting or third-party credits required.
